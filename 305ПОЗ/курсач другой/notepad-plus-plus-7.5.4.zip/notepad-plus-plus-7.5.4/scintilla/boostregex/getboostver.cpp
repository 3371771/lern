#include <stdio.h>
#include <boost/version.hpp>

int main(int argc, char* argv[])
{

   printf("%s", BOOST_LIB_VERSION);
   return 0;
}