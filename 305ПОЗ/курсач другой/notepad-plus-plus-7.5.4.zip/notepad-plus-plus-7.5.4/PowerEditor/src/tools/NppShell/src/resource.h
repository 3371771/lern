#define IDI_ICON_NPP                    102

#define IDD_DIALOG_SETTINGS             101

#define IDC_CHECK_USECONTEXT            1000
#define IDC_CHECK_CONTEXTICON           1001
#define IDC_EDIT_MENU                   1002
#define IDC_EDIT_COMMAND                1003
#define IDC_CHECK_USEICON               1004
#define IDC_CHECK_ISDYNAMIC             1005

#define IDC_STATIC                      -1
